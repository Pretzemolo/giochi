# Corsa del pan di zenzero

Runner infinito per browser: un omino di pan di zenzero attraversa 20 biomi, dal deserto al Polo Nord, e vince quando arriva alla casa di Babbo Natale.

## Come si gioca

Apri `index.html` in un browser, oppure pubblicalo con GitHub Pages.

- **Saltare:** Spazio, ↑, W oppure tocca lo schermo. In aria puoi fare un secondo salto; tieni premuto per saltare più in alto.
- **Abbassarsi:** ↓ o S (oppure il pulsante "Abbassati").
- **Pausa:** P · **Audio:** M

## Biomi

Deserto, Canyon al tramonto, Savana, Giungla, Spiaggia, Fondale marino, Foresta d'autunno, Bosco incantato, Palude, Cimitero spettrale, Vulcano, Grotta di cristalli, Montagne, Paese dei dolci, Pineta innevata, Lago ghiacciato, Tundra, Villaggio degli elfi, Bufera polare, Casa di Babbo Natale.

Un unico file HTML, senza dipendenze (solo i font da Google Fonts).
